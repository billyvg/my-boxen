# Java Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-java.png?branch=master)](https://travis-ci.org/boxen/puppet-java)

Installs Java 7u51 and unlimited key length security policy files..


## Usage

```puppet
include java
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
